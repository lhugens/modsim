#!/usr/bin/env python3 

import os
import time
we = "./a.out < leggimi.txt > spartaaa" 
os.system(we)
